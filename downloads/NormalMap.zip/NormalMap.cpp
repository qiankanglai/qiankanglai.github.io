#include <stdio.h>
#include <assert.h>

#include "CImg.h"
using namespace cimg_library;

enum EdgeDetector
{
	Sobel,
	Scharr
};
struct vec3
{
	float x, y, z;
	vec3(float _x, float _y, float _z)
	{
		x = _x;
		y = _y;
		z = _z;
	}
	float dot(const vec3& rhs)
	{
		return x*rhs.x + y*rhs.y + z*rhs.z;
	}
	float magnitude()
	{
		float l = x*x + y*y + z*z;
		return sqrtf(l);
	}
	void normalize()
	{
		float t = magnitude();
		assert(t > 0);
		x /= t;
		y /= t;
		z /= t;
	}
};

vec3 tex2D(const CImg<unsigned char>& img, int x, int y, int x_offset = 0, int y_offset = 0)
{
	x = (x + x_offset + img.width()) % img.width();
	y = (y + y_offset + img.height()) % img.height();
	return vec3(img(x, y, 0) / 255.0f, 
		img(x, y, 1) / 255.0f, 
		img(x, y, 2) / 255.0f);
}

static vec3 gray_operator(0.2126f, 0.7152f, 0.0722f);

// dirty & tricky here :(
inline unsigned char saturate_cast(float t)
{
	if (t < 0) return 0;
	if (t > 255) return 255;
	return static_cast<unsigned char>(t);
}

CImg<unsigned char> NormalMap(const CImg<unsigned char>& img,
	float dz,
	EdgeDetector detector = Sobel, 
	bool invertR = false, 
	bool invertG = false,
	bool invertH = false)
{
	CImg<unsigned char> output(img.width(), img.height(), img.depth(), img.spectrum());
	float step_x = 1.0f / img.width(), step_y = 1.0f / img.height();
	for (int y = 0; y < img.height(); y++)
	{
		for (int x = 0; x < img.width(); x++)
		{
			// using grayscale rather than simply R channel
			float tl = abs(tex2D(img, x, y, -1,  1).dot(gray_operator));
			float l  = abs(tex2D(img, x, y, -1,  0).dot(gray_operator));
			float bl = abs(tex2D(img, x, y, -1, -1).dot(gray_operator));
			float t  = abs(tex2D(img, x, y,  0,  1).dot(gray_operator));
			float b  = abs(tex2D(img, x, y,  0, -1).dot(gray_operator));
			float tr = abs(tex2D(img, x, y,  1,  1).dot(gray_operator));
			float r  = abs(tex2D(img, x, y,  1,  0).dot(gray_operator));
			float br = abs(tex2D(img, x, y,  1, -1).dot(gray_operator));

			float dx = 0, dy = 0;
			if (detector == Sobel)
			{
				dx = tl + l * 2 + bl - tr - r * 2 - br;
				dy = tl + t * 2 + tr - bl - b * 2 - br;
			}
			else if (detector == Scharr)
			{
				dx = tl * 3 + l * 10 + bl * 3 - tr * 3 - r * 10 - br * 3;
				dy = tl * 3 + t * 10 + tr * 3 - bl * 3 - b * 10 - br * 3;
			}
			else
			{
				assert(false);
			}
			if (invertR) dx *= -1;
			if (invertG) dy *= -1;
			if (invertH) { dx *= -1; dy *= -1; }

			vec3 normal(dx, dy, dz);
			normal.normalize();
			output(x, y, 0) = saturate_cast((normal.x * 0.5f + 0.5f) * 255);
			output(x, y, 1) = saturate_cast((normal.y * 0.5f + 0.5f) * 255);
			output(x, y, 2) = saturate_cast((normal.z) * 255);
		}
	}
	return output;
}

CImg<unsigned char> DisplacementMap(const CImg<unsigned char>& img,
	float contrast, bool invert = false)
{
	CImg<unsigned char> output(img.width(), img.height(), img.depth(), img.spectrum());
	static const float k = 259.0f / 255.0f;
	float factor = (k * (contrast + 1.0f)) / (1.0f * (k - contrast));
	printf("%lf", factor);
	for (int y = 0; y < img.height(); y++)
	{
		for (int x = 0; x < img.width(); x++)
		{
			vec3 v = tex2D(img, x, y);
			float greyval = v.dot(gray_operator);
			if (invert) greyval = 1.0f - greyval;
			greyval = factor * (greyval - 0.5f) + 0.5f;

			output(x, y, 0) = saturate_cast(greyval * 255);
			output(x, y, 1) = saturate_cast(greyval * 255);
			output(x, y, 2) = saturate_cast(greyval * 255);
		}
	}
	return output;
}
int main()
{
	CImg<unsigned char> input("test.bmp");
	CImgDisplay input_disp(input, "Input");

#if 1
	float strength = 2.5f;
	float level = 7.0f;
	float blur = 0.2f;
	float dz = 1.0f / strength * (1 + powf(2.0f, level)) / 255;
	CImg<unsigned char> normal = NormalMap(input, dz);
	// Blur/Sharpen with Gaussian -.-
	normal = normal.blur(blur);
	CImgDisplay normal_disp(normal, "NormalMap");
	while (!normal_disp.is_closed()) {
		normal_disp.wait();
	}
#endif

#if 0
	float contrast =  0.2f;
	CImg<unsigned char> displacement = DisplacementMap(input, contrast);
	CImgDisplay displacement_disp(displacement, "DisplacementMap");
	while (!displacement_disp.is_closed()) {
		displacement_disp.wait();
	}
#endif

	//AmbientOcclusion: sobel -> gaussian sharpen/blur

	//Specular: calculate lumiance, rearrange it in specular domain by different fall methods
	return 0;
}