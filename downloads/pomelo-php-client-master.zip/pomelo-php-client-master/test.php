<?php
require("PomeloClient.php");

$client = new PomeloClient();
$client->onConnect(function($pomeloClient){
  $pomeloClient->request("chat.woc.entry", 
    array("uid"=>"112", "world"=>"1", "team"=>"s", "name"=>"哈"), 
    function($response){
      echo "callback:\n".$response."\n";
    });  
});
$client->listen("onCHAT", function($response){
      echo "notify:\n".$response."\n";
});
$client->connect("127.0.0.1", 14100);