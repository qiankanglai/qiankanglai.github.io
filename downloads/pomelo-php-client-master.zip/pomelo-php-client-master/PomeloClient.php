<?php
error_reporting(E_ALL);

class PomeloClient {
  private $client = NULL;
  private $isConnected = false;

  private $onConnectCallback = NULL;
  private $onErrorCallback = NULL;
  private $onKickCallback = NULL;
  private $onCloseCallback = NULL;
  
  private $heartbeatInterval = 0;
  private $heartbeatTimeout = 0;
  private $nextHeartbeatTimeout = 0;

  private $dict = array();
  private $abbr = array();
  private $protos = array();
  private $protosVersion = 0;
  private $serverProtos = array();
  private $clientProtos = array();

  private $reqIdIndex = 0;
  private $routeMap = array();
  private $onDataHandlerMap = array();
  private $onRouteHandlerMap = array();

  function __construct(){
    $this->client = new swoole_client(SWOOLE_SOCK_TCP, SWOOLE_SOCK_ASYNC);

    $this->client->on("connect", function(swoole_client $cli){
      $handshakeMessage = $this->handshakeObject();
      $encode = $this->encodePackage($this::TYPE_HANDSHAKE, $handshakeMessage);
      $cli->send($encode);
    });

    $this->client->on("receive", function(swoole_client $cli, $data){
      $decode = $this->decodePackage($data);
      switch ($decode["type"]) {
        case $this::TYPE_HANDSHAKE: {
          $this->handshake($decode["body"]);
          break;
        }
        case $this::TYPE_HEARTBEAT: {
          $this->heartbeat($decode["body"]);
          break;
        }
        case $this::TYPE_DATA: {
          $this->onData($decode["body"]);
          break;
        }
        case $this::TYPE_KICK: {
          if($this->onKickCallback != NULL)
            call_user_func($this->onKickCallback, $this);
          else
            echo "onKick!";
          break;
        }
      }
      if($this->heartbeatTimeout > 0){
        $this->nextHeartbeatTimeout = $this->heartbeatTimeout + time();
      }
    });

    $this->client->on("error", function(swoole_client $cli){
      if($this->onErrorCallback != NULL)
        call_user_func($this->onErrorCallback, $this);
    });
    $this->client->on("close", function(swoole_client $cli){
      if($this->onCloseCallback != NULL)
        call_user_func($this->onCloseCallback, $this);
    });
  }

  function connect($host, $port){
    $result = $this->client->connect($host, $port, 0.5, 0);
  }

  function onConnect($callback){
    $this->onConnectCallback = $callback;
  }
  function onError($callback){
    $this->onErrorCallback = $callback;
  }
  function onKick($callback){
    $this->onKickCallback = $callback;
  }
  function onClose($callback){
    $this->onCloseCallback = $callback;
  }

  function request($route, $params, $handler){
    $this->reqIdIndex++;
    
    $message = $this->encodeMessage($this->reqIdIndex, $route, json_encode($params, true));
    $encode = $this->encodePackage($this::TYPE_DATA, $message);
    $this->client->send($encode);

    $this->routeMap[$this->reqIdIndex] = $route;
    $this->onDataHandlerMap[$this->reqIdIndex] = $handler;
  }

  function listen($route, $handler){
    $this->onRouteHandlerMap[$route] = $handler;
  }

  //==========HANDSHAKE==========

  const CLIENT_TYPE = "php-swoole";
  const CLIENT_VERSION = "0.0.1";

  const HANDSHAKE_SYS_KEY = "sys";
  const HANDSHAKE_SYS_TYPE_KEY = "type";
  const HANDSHAKE_SYS_VERSION_KEY = "version";
  const HANDSHAKE_SYS_HEARTBEAT_KEY = "heartbeat";
  const HANDSHAKE_SYS_DICT_KEY = "dict";
  const HANDSHAKE_SYS_PROTOS_KEY = "protos";
  const HANDSHAKE_SYS_PROTOS_VERSION_KEY = "version";
  const HANDSHAKE_SYS_PROTOS_SERVER_KEY = "server";
  const HANDSHAKE_SYS_PROTOS_CLIENT_KEY = "client";
  const HANDSHAKE_USER_KEY = "user";

  function handshakeObject() {
    $sys = array(self::HANDSHAKE_SYS_TYPE_KEY=>self::CLIENT_TYPE,
     self::HANDSHAKE_SYS_VERSION_KEY=>self::CLIENT_VERSION);
    $user = array();
    $handshake = array(self::HANDSHAKE_SYS_KEY=>$sys, self::HANDSHAKE_USER_KEY=>$user);
    return json_encode($handshake, JSON_FORCE_OBJECT);
  }

  function handshake($body){
    $json = json_decode($body, true);
    if (!isset($json[$this::RES_CODE_KEY])) {
      echo "[handshake]res data error!";
      return;
    }
    if ($this::RES_OLD_CLIENT == $json[$this::RES_CODE_KEY]) {
      echo "[handshake]old version";
      return;
    }
    if ($this::RES_FAIL == $json[$this::RES_CODE_KEY]) {
      echo "[handshake]failure";
      return;
    }

    //handshakeInit
    if (!isset($json[$this::HANDSHAKE_SYS_KEY])) {
      echo "[handshake]data format error";
      return;
    }
    $sys = $json[$this::HANDSHAKE_SYS_KEY];
    if (isset($sys[$this::HANDSHAKE_SYS_HEARTBEAT_KEY])) {
      $heartbeat = $sys[$this::HANDSHAKE_SYS_HEARTBEAT_KEY];
      $this->heartbeatInterval = $heartbeat;
      $this->heartbeatTimeout = $this->heartbeatInterval * 2;
    }

    //initData
    if (isset($sys[$this::HANDSHAKE_SYS_DICT_KEY])) {
      $this->dict = $sys[$this::HANDSHAKE_SYS_DICT_KEY];
      foreach ($this->dict as $key => $value) {
        $this->abbr[$value] = $key;
      }
    }
    if (isset($sys[$this::HANDSHAKE_SYS_PROTOS_KEY])){
      $this->protos = $sys[$this::HANDSHAKE_SYS_PROTOS_KEY];
      $this->protosVersion = isset($sys[$this::HANDSHAKE_SYS_PROTOS_VERSION_KEY])?isset($sys[$this::HANDSHAKE_SYS_PROTOS_VERSION_KEY]):0;
      $this->serverProtos = isset($sys[$this::HANDSHAKE_SYS_PROTOS_SERVER_KEY])?isset($sys[$this::HANDSHAKE_SYS_PROTOS_SERVER_KEY]):array();
      $this->clientProtos = isset($sys[$this::HANDSHAKE_SYS_PROTOS_CLIENT_KEY])?isset($sys[$this::HANDSHAKE_SYS_PROTOS_CLIENT_KEY]):array();
      //throw new Exception("unsupport Protobuf yet!");
    }

    //send ack msg
    $ack = $this->encodePackage($this::TYPE_HANDSHAKE_ACK, NULL);
    $this->client->send($ack);
    echo "connected!\n";
    $this->isConnected = true;
    if($this->onConnectCallback != NULL)
      call_user_func($this->onConnectCallback, $this);
  }

  //==========HEARTBEAT==========

  function heartbeat($body){
    if($this->heartbeatInterval == 0){
      return;
    }
    $encode = $this->encodePackage($this::TYPE_HEARTBEAT, NULL);
    $this->client->send($encode);

    $this->nextHeartbeatTimeout = time() + $this->heartbeatTimeout;
  }

  //==========RESPONSE==========

  const RES_CODE_KEY = "code";
  const RES_OK = 200;
  const RES_FAIL = 500;
  const RES_OLD_CLIENT = 501;

  function onData($body){
    $message = $this->decodeMessage($body);

    $id = $message["id"];
    if(!empty($this->onDataHandlerMap[$id])){
        call_user_func($this->onDataHandlerMap[$id], $message["body"]);
        unset($this->onDataHandlerMap[$id]);
    }
    else{
      $route = $message["route"];
      if(!empty($this->onRouteHandlerMap[$route]))
        call_user_func($this->onRouteHandlerMap[$route], $message["body"]);
      else{
        echo "[onData]no callback:\n";
        var_dump($message);
      }
    } 
  }
  
  //==========MESSAGE ENCODE/DECODE==========
  const MSG_FLAG_BYTES = 1;
  const MSG_ROUTE_CODE_BYTES = 2;
  const MSG_ID_MAX_BYTES = 5;
  const MSG_ROUTE_LEN_BYTES = 1;

  const MSG_ROUTE_CODE_MAX = 0xffff;

  const MSG_COMPRESS_ROUTE_MASK = 0x1;
  const MSG_TYPE_MASK = 0x7;

  const TYPE_REQUEST = 0;
  const TYPE_NOTIFY = 1;
  const TYPE_RESPONSE = 2;
  const TYPE_PUSH = 3;

  const MSG_ROUTE_KEY = "route";

  function encodeMsgId($id) {
    $buffer = array();
    do {
      $tmp = $id % 128;
      $next = intval(floor($id / 128.0));
      if ($next != 0) {
        $tmp = $tmp + 128;
      }
      $buffer[] = $tmp;
      $id = $next;
    } while ($id != 0);
    $buffer = implode(array_map("chr", $buffer));
    return $buffer;
  }

  function encodeMessage($reqId, $route, $message){
    $type = ($reqId > 0) ? $this::TYPE_REQUEST : $this::TYPE_NOTIFY;
    if(isset($this->clientProtos[$route])){
      throw new Exception("unsupport Protobuf yet!");
    }
    else{
      $encode = json_encode($message);
    }
    $compressRoute = false;
    if(isset($this->dict[$route])){
      $compressRoute = true;
      $route = $this->dict[$route];
    }

    $encodeMsgFlag = chr($type<<1 | ($compressRoute?1:0));
    $encodeMsgId = ($type == $this::TYPE_REQUEST || type == $this::TYPE_RESPONSE)?$this->encodeMsgId($reqId):NULL;
    if($type == $this::TYPE_REQUEST || $type == $this::TYPE_NOTIFY || $type == $this::TYPE_PUSH){
      if($compressRoute){
        $encodeMsgRoute = pack("C2", $route>>8, $route&0xff);
      }
      else{
        if($route != NULL)
          $encodeMsgRoute = pack("C", strlen($route)).$route;
        else
          $encodeMsgRoute = pack("C", 0);
      }
    }
    else
      $encodeMsgRoute = NULL;
    $encodeMsgBody = $message;

    return $encodeMsgFlag.$encodeMsgId.$encodeMsgRoute.$encodeMsgBody;
  }

  function decodeMessage($body){
    $buffer = unpack("C*", $body);

    $flag = $buffer[1];
    $compressRoute = $flag & $this::MSG_COMPRESS_ROUTE_MASK;
    $type = ($flag >> 1) & $this::MSG_TYPE_MASK;
    $offset = 2;

    $id = 0;
    // parse id
    if($type == $this::TYPE_REQUEST || $type == $this::TYPE_RESPONSE){
        $i = 1;
        do {
          $m = $buffer[$offset] & 0xff;
          $id = $id + ($m & 0x7f) * $i;
          $offset++;
          $i=$i*128;
        } while ($m >= 128);
    }
    // parse route
    if($type == $this::TYPE_REQUEST || $type == $this::TYPE_NOTIFY || $type == $this::TYPE_PUSH){
        if($compressRoute){
            $route = (($buffer[$offset++] & 0xff) << 8) | ($buffer[$offset++] & 0xff);
            if(isset($this->abbr[$route]))
                $route = $this->abbr[$route];
        }
        else{
            $routeLen = $buffer[$offset++];
            if($routeLen > 0){
                $route = array_slice($buffer, $offset-1, $routeLen);
                $route = implode(array_map("chr", $route));
            }
            else
                $route = "";
            $offset += $routeLen;
        }
    }
    else{
        $route = NULL;
        if(isset($routeMap[$id]))
            $route = $routeMap[$id];
    }

    unset($routeMap[$id]);

    $body = array_slice($buffer, $offset-1);
    $body = implode(array_map("chr", $body));
    return array("id"=>$id, "route"=>$route, "body"=>$body);
  }

  //==========PACKAGE ENCODE/DECODE==========

  const PKG_HEAD_BYTES = 4;

  const TYPE_HANDSHAKE = 1;
  const TYPE_HANDSHAKE_ACK = 2;
  const TYPE_HEARTBEAT = 3;
  const TYPE_DATA = 4;
  const TYPE_KICK = 5;

  function encodePackage($type, $body){
    //Kanglai: we don't need strencode in PHP, since unpack("c*") here has the same result with strencode in Java!
    $length = isset($body)?strlen($body):0;     //sizeof(unpack("c*", $body));
    $header = pack("C4", $type, ($length>>16)&0xff, ($length>>8)&0xff, $length&0xff);
    $buffer = $header.$body;
    return $buffer;
  }
  function decodePackage($buffer){
    $data = unpack("C*", $buffer);
    $type = $data[1];
    $length = ($data[2] << 16) | ($data[3] << 8) | $data[4];
    $body = array();
    if($length > 0){
      $body = array_slice($data, $this::PKG_HEAD_BYTES, $length);
      $body = implode(array_map("chr", $body));
    }
    return array("type"=>$type, "body"=>$body);
  }
}
